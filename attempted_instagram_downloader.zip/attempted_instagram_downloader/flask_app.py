from flask import Flask, request, render_template, session, redirect, url_for
import insta_pic


app = Flask(__name__, template_folder='template')

app.secret_key = 'test'

@app.route("/")
def run_script():
    return insta_pic.insta_fnc() 


if __name__ == '__main__':
#    (host='0.0.0.0', port='8000',  
   app.run(debug=True)
    # app.run(debug=True)

"""To run this code, open the terminal and type the command 'python flask_app.py' and press enter.
Next, still in the terminal, type in the user's name on instagram, eg;geraldinennene.
The successful download message will pop up.
To get the photos, navigate to the location of the project and look for the user's name you typed in. You'll 
see the photos.
"""
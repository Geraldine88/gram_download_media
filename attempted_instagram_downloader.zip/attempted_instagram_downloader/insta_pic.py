#from crypt import methods
from distutils.log import debug
import instaloader


def insta_fnc():
    # Creating an instagram loader class 
    insta = instaloader.Instaloader()

    # #Request from the user
    request_user =  input("Enter user name: ")
  
     # Getting the user's data on instagram
    insta_prof =  insta.download_profile(request_user, profile_pic_only=False)

    return("Download is complete!!")
